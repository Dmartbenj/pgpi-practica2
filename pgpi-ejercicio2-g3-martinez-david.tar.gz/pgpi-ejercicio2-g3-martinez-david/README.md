# Práctica 2 PGPI: Filtro Antirrebotes (Debouncer en C)
Proyecto base para la práctica de Git Avanzado en C (Linux).
proyecto de ejemplo practica

## Compilación y Ejecución
```bash
make clean
make
./test_debouncer
